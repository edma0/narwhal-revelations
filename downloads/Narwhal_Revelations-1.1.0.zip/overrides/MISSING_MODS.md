# Mods from your 1.20.1 server with no NeoForge 1.21.1 build

Checked by hand on CurseForge (every file of each project) and Modrinth on 3 Nov 2026. 27 of your 210 mods had no official NeoForge 1.21.1 build. In version 1.1.0 the 7 that have a community or unofficial port are INCLUDED (table 1). 20 are still missing (table 2): 15 have nothing I could verify, 5 are not needed any more.

## 1. Now included: community and unofficial ports (new in 1.1.0)

These are separate projects by other authors, not the original mods. Every file below was checked for the NeoForge loader tag and the 1.21.1 game version tag, and for the Client and Server environment tags on CurseForge or Modrinth. All are installed on the server and the client.

| Your old mod | Port in the pack | Source and ids | File | Tags | Extra libraries it needs (also included) |
|---|---|---|---|---|---|
| Alex's Caves | Alex's Caves Neo | CurseForge 1613404 / file 8891461 | alexscaves-2.0.3.jar | NeoForge, 1.21.1, Client, Server | Citadel |
| Alex's Mobs | Alex's Mobs Neo | CurseForge 1613387 / file 8890602 | alexsmobs-1.22.9.jar | NeoForge, 1.21.1, Client, Server | Citadel |
| Botania | Botania Revived | CurseForge 1725641 / file 9408183 | Botania-Revived-1.21.1-1.0.5-NeoForge.jar | NeoForge, 1.21.1, Client, Server | Patchouli |
| Construction Wand | Construction Wands Revived | CurseForge 1395288 / file 9297941 | ConstructionWandsRevived-1.21.1-4.0.13-NeoForge.jar | NeoForge, 1.21.1, Client, Server | none |
| Enigmatic Graves (fork) | Corail Tombstone | CurseForge 243707 / file 8842741 | tombstone-neoforge-1.21.1-9.5.6.jar | NeoForge, 1.21 and 1.21.1, Client, Server | none |
| Ice and Fire | IceAndFire Community Edition | CurseForge 1040076 / file 9128508 | iceandfire-2.1.4.jar | NeoForge, 1.21.1, Client, Server | Uranus 2.4.1-bugfix, Jupiter 2.3.7 |
| Tinkers' Construct | Tinkers Construct (Unofficial port) | Modrinth 3xgZFdrY / version SbT1iise (1.21.1-1.6.1-NeoForge, released 2 Nov 2026) | TinkersConstruct-Unofficial-Port-1.21.1-1.6.1-NeoForge.jar | Modrinth: neoforge, 1.21.1, client and server required | Hilt 1.14 (not Mantle) |

Note on Tinkers: the jar is named Tinkers Construct (Unofficial port) but its mod id is `modernfoundry` (it carries Modern Foundry's code and content, based on Tinkers' Construct). Items use the `modernfoundry:` namespace, not `tconstruct:`. Old Tinkers recipes, scripts or add-ons that mention `tconstruct:` ids will not match. It is Modrinth-only, so it sits in overrides/mods of the pack zip.

Alex's Caves Neo, Alex's Mobs Neo and IceAndFire CE are different projects from the originals. Saves from the originals are not compatible. This pack starts a new world anyway.

## 2. Still missing

| Mod | What it did | Status on 1.21.1 | Suggested replacement |
|---|---|---|---|
| Beyond Mines: Potion Amulets | Pack-specific mod from the Beyond Mines team that adds potion amulet items. | One CurseForge file only (1.0.0, Forge 1.20.1, Jan 2024). Not on Modrinth. | None found. |
| CoFH Core | Library mod that Thermal Expansion and Thermal Foundation need. | Last NeoForge-tagged file is 1.20.1 (May 2024). No 1.21.1 file. | None. It is only needed by the Thermal mods. |
| Computer Cartographer | Add-on for CC: Tweaked computers (map access). | Two CurseForge files (Forge and Fabric, 1.20.1, Nov 2023). Not on Modrinth for 1.21.1. | None found. |
| Create: Steam 'n' Rails | Create add-on with steam locomotives, tracks and train parts. | Forge, NeoForge-tagged and Fabric builds stop at 1.20.1 (v1.7.3, 27 Aug 2026). No 1.21.1 file anywhere. | None verified. |
| Dragon Finder | Small Ice and Fire add-on that locates dragons. | Forge, NeoForge-tagged and Fabric 1.20.1 only. | None found. It targets the original Ice and Fire, not the Community Edition in this pack. |
| Ecospherical Expansion | Biome and world-generation expansion. | Forge and Fabric builds up to 1.20.2 only. | None found. |
| Elemental Animals | Adds elemental-themed animals. | Eight CurseForge files, Forge 1.19.2 to 1.20.1. Not on Modrinth. | None found. |
| Enchantable Boat | Lets you enchant boats. | Forge 1.20.1 only (v1.5.4, Jul 2025). | None found. |
| Ender Crop | Adds an ender-themed farmable crop. | Forge and NeoForge-tagged 1.20.1 only (Aug 2023). | None found. |
| Iron Bows (Forge) | Adds iron-tier bows. | Only a Forge 1.21.1 beta exists (ironbows-1.11-forge-1.21.1.jar, Sep 2024). Not NeoForge. | None found. |
| Item Filters | Library for item-filter items used by other mods. | Last file is 1.20.1 (Nov 2023). | Not needed: none of the 205 mods in the new pack depends on it (checked in every jar's dependency list). |
| KubeJS + CC: Tweaked | Lets KubeJS scripts talk to CC: Tweaked computers. | One beta file, Forge 1.20.1 (May 2024). | Not needed: your scripts do not use it. |
| Mantle | Library for Tinkers' Construct. | Latest file is 1.20.1 (v1.11.117, Sep 2026). No 1.21.1 file. | Not needed: the Tinkers' Construct port in this pack uses Hilt (included) instead of Mantle. |
| Refined Storage Addons | Extra storage and wireless features for Refined Storage 1. Refined Storage is now 2.0.9 in the new pack, a full rewrite. | Latest files are Forge 1.20.1 and NeoForge 1.20.4. No 1.21.1 file. | Already in the pack for Refined Storage 2: Extra Disks, ExtraStorage and RSRequestify. |
| serializationisbad | Security patch for Forge 1.20.x serialisation. | Latest file is Forge 1.20.4. | Not needed: nothing in the new pack depends on it and there is no 1.21 build. |
| Simple Farming | Crop and farming additions. | Forge 1.20.1 only (Aug 2023). | None found. |
| Simple Hot Air Balloons | Hot air balloon vehicles. | Forge 1.20.1 and NeoForge 1.20.4 only. | None found. |
| Thermal Expansion | Thermal series machines (pulverizer, furnace, and so on). | Official builds stop at 1.20.1 (May 2024). | None. A community GitHub repo claims a 1.21.1 port but has no releases, so I am not suggesting it. |
| Thermal Foundation | Thermal series ores, metals and tools. | Official builds stop at 1.20.1 (Jun 2024). | None. Same as Thermal Expansion. |
| Tinkers' Better Combat | Better Combat support for Tinkers' tools. | Forge 1.20.1 only (v0.14, Apr 2026). | None found. It targets Tinkers' Construct's tconstruct: ids; the port in this pack uses modernfoundry: ids. |

## Found, but only on Modrinth (included as jars in overrides/mods)

| Mod | Version in pack | Channel |
|---|---|---|
| CC: Tweaked | cc-tweaked-1.21.1-forge-1.120.2.jar | alpha |
| Ender Storage | EnderStorage-1.21.1-2.13.0.191.jar | release |
| GlitchCore | GlitchCore-neoforge-1.21.1-2.1.0.2.jar | beta |
| Iron Barrels | IronBarrels1.21.1-V1.02NeoForge.jar | release |
| Noisium | noisium-neoforge-2.3.0+mc1.21-1.21.1.jar | release |
| YUNG's API | YungsApi-1.21.1-NeoForge-5.1.9.jar | release |
| YUNG's Better Mineshafts | YungsBetterMineshafts-1.21.1-NeoForge-5.1.1.jar | release |
| Tinkers Construct (Unofficial port) | TinkersConstruct-Unofficial-Port-1.21.1-1.6.1-NeoForge.jar | release |

Because these are jars inside the pack zip, it can be imported into the CurseForge app but not published on CurseForge.

## Dependencies added that were not on your server

| Mod | File |
|---|---|
| Data Anchor | Data_Anchor-neoforge-1.21.1-2.0.0.18.jar |
| Prickle | prickle-neoforge-1.21.1-21.1.11.jar |
| Create: Dragons Plus | CreateDragonsPlus-1.11.9.jar |
| YetAnotherConfigLib | yet_another_config_lib_v3-3.8.2+1.21.1-neoforge.jar |
| Configurable | configurable-3.5.3+1.21.1-neoforge.jar |
| PolyLib | polylib-2100.1.0-build.183-neoforge.jar |
| Fzzy Config | fzzy_config-0.7.7+fix1+1.21+neoforge.jar |
| Simply Tooltips | SimplyTooltips-neoforge-0.1.5.jar |
| Iron Core | IronCore1.20.1-V1.0NeoForge.jar |
| Moogs Structure Lib | MoogsStructureLib-neoforge-1.21.1-3.4.2.jar |
| GuideME | guideme-21.1.22.jar |
| Hilt | Hilt-1.21.1-1.14.jar |
| Uranus | uranus-2.4.1-bugfix-1.21.1-neoforge.jar |
| Jupiter | jupiter-2.3.7-1.21.1-neoforge.jar |
| Unbreakables | unbreakables-neoforge-1.21.1-21.1.15.jar (added so your Waystones generatedWaystonesUnbreakable setting can be carried; server-side) |

## Included but not a full release

| Mod | File | Channel |
|---|---|---|
| Create Stuff & Additions | create-stuff-additions1.21.1_v2.1.4b.jar | beta |
| Draconic Evolution | Draconic-Evolution-1.21.1-3.1.4.633.jar | beta |
| Ender IO | enderio-8.2.12-beta.jar | beta |
| Extra Disks | ExtraDisks-1.21.1-4.0.15.jar | beta |
| Framework | framework-neoforge-1.21.1-0.13.11.jar | beta |
| McJtyLib | mcjtylib-1.21-9.0.22.jar | beta |
| Player Animator | player-animation-lib-forge-2.0.4+1.21.1.jar | beta |
| RFToolsBase | rftoolsbase-1.21-6.0.11.jar | beta |
| RSRequestify | rsrequestify-1.21.1-3.0.0.jar | beta |
| Serene Seasons | SereneSeasons-neoforge-1.21.1-10.1.0.3.jar | beta |
| Iron Core | IronCore1.20.1-V1.0NeoForge.jar | beta |
| CC: Tweaked | cc-tweaked-1.21.1-forge-1.120.2.jar | alpha |
| GlitchCore | GlitchCore-neoforge-1.21.1-2.1.0.2.jar | beta |
