# PORTING NOTES: Narwhal Revelations 1.1.0 (Minecraft 1.21.1, NeoForge 21.1.265)

Built from your server at C:\MinecraftServers\Narwhal_BM_Revelations_II-1.2.1 (Minecraft 1.20.1, Forge 47.3.0, 210 mods). Nothing in that folder was changed.

Mods in this pack: 205 jars: 176 of your 210 mods, the 7 community ports, 14 dependencies and 1 helper mod (Unbreakables). 8 jars come from Modrinth. 180 run on the server, 25 are client-only.
Mods with no NeoForge 1.21.1 build are in MISSING_MODS.md.

## Where server configs live on this NeoForge version
NeoForge 1.21 writes server-side configs (the `*-server.toml` and `*-world.snbt` files) into `config/`. On your 1.20.1 server they were in `world/serverconfig/`. The carried values below are therefore in `config/`. A file in `world/serverconfig/` would override them.

## Your edits, carried into this pack
Only keys that still exist in the 1.21.1 versions of the mods were written. Each file in `config/` is the 1.21.1 default file with just your values changed.

| File | Your value (old default) | In this pack |
|---|---|---|
| config/Mekanism/gear.toml | Atomic Disassembler maxEnergy 2500000 (1000000), chargeRate 12500 (5000) | Same keys, carried |
| config/industrialforegoing/machine-resource-production.toml | OreLaserBaseConfig maxProgress 10000 (100), catalystModifier 1 (8) | Same keys, carried. Your script also bans this machine |
| config/reliquary-common.toml | disable.alkahestryTome true (false); mobCharmFragment dropChance 0 (0.0167), lootingMultiplier 0 (0.0083) | Same keys, carried |
| config/ftbchunks-world.snbt | force_load_mode "always" ("default"), max_force_loaded_chunks 75 (25) | Same keys, carried. Found by comparing world/serverconfig with a fresh 1.20.1 boot |
| config/waystones-common.toml | worldgen frequency 16 (25) | Mapped to `chunksBetweenWildWaystones = 16`. Same meaning in the 1.21.1 config |
| config/waystones-common.toml | minimumBaseXpCost 1 (0.0) | Mapped to `min_xp_cost(1)` in `warpRequirements`. Closest equivalent, check in game |
| config/waystones-common.toml | warpStoneCooldown 120 s (30) | New in 1.1.0: added `[source_is_warp_stone] add_cooldown(warp_stone, 120)` to `warpRequirements`. The cooldown id is free text, so `warp_stone` is my name for it. It is per player and shared by all warp stones, as before. The config loads and keeps the line, but I could not test the cooldown with a real player |
| config/waystones-common.toml | restrictToCreative true (false) | New in 1.1.0, partly carried: `restrictedWaystones` now lists every origin (PLAYER, WILDERNESS, DUNGEON, VILLAGE, UNKNOWN). Generated waystones can then only be edited by players with the Waystones edit-all permission, and player-placed ones only by their owner. 1.21.1 has no 'creative mode only' switch, so a survival owner can still edit his own waystone |
| config/unbreakables-common.toml + the Unbreakables mod | generatedWaystonesUnbreakable true (false) | New in 1.1.0: Waystones 1.21.1 handles this through the separate Unbreakables mod (server-side, added to the pack for this). Config: `rulesets = ["waystones:generated_waystones"]`. Boot log: "1 breakable rules loaded". Not tested by breaking a block in game |
| config/alexscaves_biome_generation/ candy_cavity, forlorn_hollows, magnetic_caves, toxic_caves .json | `disabled_completely` true (false) | New in 1.1.0: Alex's Caves Neo 2.0.3 uses the same file names and keys. The four files are byte-for-byte your files. abyssal_chasm and primordial_caves stay enabled, as on your server |
| world/datapacks/DoubleExp | Double Exp datapack (extra 5 XP per orb) | New in 1.1.0: shipped in the server pack as `world/datapacks/DoubleExp` with `pack_format` 48. Your copy already used the 1.21 folder names (`function`, singular), which Minecraft 1.20.1 does not read (it wanted `functions`), so it probably did nothing on the old server. Only the format number changed. A new server picks it up on first start: the log says "Found new data pack file/DoubleExp, loading it automatically" and `datapack list` shows it enabled. `function double:load` and `double:tick` run without errors |
| server.properties | difficulty hard, spawn-protection 0, view-distance 16, simulation-distance 10, level-seed -6384763642895912697, enforce-secure-profile true, generate-structures true, level-type minecraft:normal, initial-enabled-packs vanilla, your motd | Carried (server pack only) |
| user_jvm_args.txt | -Xmx15G -Xms15G (old file also had -Dfml.readTimeout=300) | -Xmx15G -Xms15G. The readTimeout flag was a Forge 1.20.1 setting and is left out |

## Checked for the 7 community ports (new in 1.1.0)
I compared every file in your `config/` that belongs to Alex's Caves, Alex's Mobs, Ice and Fire, Tinkers' Construct, Botania and Construction Wand with the defaults from your exact 1.20.1 mod set (the clean boot used for 1.0.0). The only edits are the four Alex's Caves biome files above. Alex's Mobs (about 90 files), Ice and Fire (about 45 files) and the `*-common.toml` files are default values, so there is nothing to carry. The client files (`alexscaves-client`, `botania-client`, `tconstruct-client`, `constructionwand-client`, `mantle-client`) hold only default-looking values. Ice and Fire CE does not read the old `iceandfire-common.toml`: it writes its own `config/iceandfire/iaf-common.json` and `config/jupiter.json`.

## Intentionally dropped by the pack author

Ore Creeper (and its config) is not part of this pack by choice. It is not a missing mod.

## Your edits that could NOT be carried (and why)
| Setting | Your value | Why |
|---|---|---|
| Waystones restrictToCreative | true | Only partly carried (see above). There is no creative-only option in Waystones 1.21.1 |
| CommonCapabilities `ignoreNbtPathsForEqualityFilters` | extra entry `$.energy` | The key no longer exists. The 1.21 option is `ignoreDataComponentsForEqualityFilters` (now empty). Energy is stored per mod in many different data components (for example `mekanism:energy`, `powah:energy_stored`, `enderio:energy`), and I cannot tell which mod's items your `$.energy` was for, so I did not guess. If you want it, add those component ids to `ignoreDataComponentsForEqualityFilters` in `config/commoncapabilities-common.toml` |
| JEI list sizes (ingredient list 30 rows x 18 columns, bookmark list 30 rows x 20 columns) | client setting | JEI 19.64 for 1.21.1 uses a new config system with renamed keys, and I cannot generate its file without a client. Set them in the JEI config screen |
| Oculus shader choice (ComplementaryUnbound_r5.2.2.zip, enabled) | client setting | Oculus has no 1.21.1 build in this pack, and the shader zip is not part of the pack. Pick the shader again in Iris |
| Falling Leaves `seasonFallRate` section | auto-added | It is the mod's own default for Serene Seasons, written automatically, not an edit of yours |

## world/serverconfig (28 files)
I booted your exact 1.20.1 mod set on a clean config to get real defaults, then compared. 27 of the 28 files hold default values only. The one edit is ftbchunks-world.snbt (above). Your `defaultconfigs/ftbchunks` and `defaultconfigs/ftbxmodcompat` files are empty `{ }` stubs.

## Other locations scanned
- Root: server.properties (edited, carried), variables.txt (JAVA_ARGS, see above), user_jvm_args.txt, start.ps1, start.sh, eula.txt, ops.json, whitelist.json, banned-ips.json, banned-players.json, usercache.json, usernamecache.json, overrides.jsonl, rhino.local.properties. The player files hold your player list and are NOT carried.
- local/kubejs/dev.properties: only a timestamp differs from the default. Nothing to carry.
- kubejs/config/common.properties and client.properties: defaults apart from a timestamp.
- global_packs (319 files), scripts (11 CraftTweaker files): identical to the original pack. Not carried, they target 1.20.1 mods and recipes.
- modernfix/structureCacheV1: a runtime cache. Not carried.
- journeymap, tools: nothing config-like to carry (tools/_gen_overrides_jsonl.py is your own helper).
- world/data/starterkit/tracking.json, world/ftbchunks, world/ftbquests, world/ftbteams, advancements, stats: per-player and per-world data. Not carried. Worlds from 1.20.1 do not load on 1.21.1.
- world/datapacks/DoubleExp (1): carried in 1.1.0, see the table above.
- config/: everything that differs from the 1.20.1 defaults was either carried above, is a client setting (JEI list size, Oculus shader, Embeddium), a random id (CyclopsCore analytics id), an auto-generated reorder (Serene Seasons, Powah, Jade, AttributeFix, Every Compat), or belongs to a mod that is not in this pack.

## KubeJS scripts (kubejs/server_scripts/narwhalman, all 10 carried, updated in 1.1.0)
Test boot on KubeJS 2101.7.2: all 10 scripts load with 0 errors and 0 warnings from the scripts, and the recipe step reports `Added 4 recipes, removed 55 recipes, modified 1 recipes, with 0 failed recipes`.
What I changed to keep your intent on 1.21.1:
- efln.js: `tconstruct:efln_ball` became `modernfoundry:efln_ball` (the Tinkers port uses the modernfoundry namespace). The port has no recipe of its own for that item, so the script now removes by output and adds your TNT and flint recipe.
- banned.js, narwhalremove.js: Industrial Foregoing lenses are now `<colour>_laser_lens`. Your old `laser_lens0..15` followed the dye numbers, and I checked the mapping against the 1.20.1 jar (0 white, 2 magenta, 3 light_blue, 4 yellow, 5 lime, 6 pink, 7 gray, 8 light_gray, 9 cyan, 11 blue, 12 brown, 13 green, 14 red, 15 black). Orange (1) and purple (10) were not on your list and still are not.
- Botania Revived and Construction Wands Revived keep the `botania:orechid`, `botania:orechid_ignem` and `constructionwand:core_destruction` ids, so those lines work again.
- Removed (no such item exists, so they were the only warnings): `waystones:sharestone` and `waystones:white_sharestone` (Waystones 1.21.1 has no uncoloured or white sharestone) and `hostilenetworks:loot_fabricator` / `sim_chamber` (Hostile Networks was never installed). The other sharestones, waystone, mossy_waystone and sandy_waystone stay banned. Waystones 1.21.1 also has waystone variants that did not exist in your list (deepslate, blackstone and so on, and portstones). I did not add them, because they were not on your list.
- test.js: rewritten for 1.21. The 1.20.1 version read the old `display.Name` NBT, which does not exist any more. It now compares the `minecraft:custom_name` data component, tested with a stick named `stickyy`. For Ars Nouveau caster tomes it also checks the tome's own spell data. I could not build a scribed tome on a headless server, so the tome part is best-effort and not proven.
- runictablet.js: `#forge:normal_stone` became `#c:normal_stone`, a tag that the Tinkers port ships.
- shield.js and qol.js needed no change. narwhalcreate.js, narwhaltinkers.js and productivebees.js are completely commented out (old `onEvent` syntax), carried as they were.
KubeJS also logs 4 warnings that are not from your scripts: it cannot parse the recipes `createdeco:placard`, `ironfurnaces:upgrades/upgrade_unobtainium`, `ironfurnaces:upgrades/upgrade_vibranium` and `alexscaves:cinder_brick`, so it falls back to the vanilla reader and the recipes still load. They come from those mods' recipe formats, not from anything you wrote.
The original pack's kubejs assets and data folders are NOT carried.

## Test boot (box)
Headless dedicated server on JDK 21 with the server-side mods, a fresh world, your server.properties values and these scripts and configs: it reached "Done" with no crash (about 8 seconds after the mods loaded, with 205 mod jars in total, 180 of them on the server). Non-fatal messages seen: loot tables of Create: Enchantment Industry and Extra Disks naming items that are not registered, two Curios slot names not registered, and four Medieval Buildings tags missing references. These come from the mods themselves.
