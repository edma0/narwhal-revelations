ServerEvents.recipes(event => {
  event.remove({ id: 'minecraft:shield' });
  event.shaped(Item.of('minecraft:shield'), [
    'ABA',
    'AAA',
    ' A '
  ], {
    A: '#minecraft:planks',
    B: 'minecraft:iron_ingot'
  }).id('narwhalman:shields/shield');
});

