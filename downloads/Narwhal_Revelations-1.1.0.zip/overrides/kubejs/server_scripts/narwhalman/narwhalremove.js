// Ported to 1.21.1: laser lens ids renamed (see banned.js); sharestone/white_sharestone and Hostile Networks items dropped (not present in this pack).
ServerEvents.recipes(event => {
  [
    'mekanism:digital_miner',
    'industrialforegoing:ore_laser_base',
    'industrialforegoing:white_laser_lens',
    'industrialforegoing:magenta_laser_lens',
    'industrialforegoing:light_blue_laser_lens',
    'industrialforegoing:yellow_laser_lens',
    'industrialforegoing:lime_laser_lens',
    'industrialforegoing:pink_laser_lens',
    'industrialforegoing:gray_laser_lens',
    'industrialforegoing:light_gray_laser_lens',
    'industrialforegoing:cyan_laser_lens',
    'industrialforegoing:blue_laser_lens',
    'industrialforegoing:brown_laser_lens',
    'industrialforegoing:green_laser_lens',
    'industrialforegoing:red_laser_lens',
    'industrialforegoing:black_laser_lens',
    'botania:orechid',
    'botania:orechid_ignem',
    'waystones:waystone',
    'waystones:mossy_waystone',
    'waystones:sandy_waystone',
    'waystones:orange_sharestone',
    'waystones:magenta_sharestone',
    'waystones:light_blue_sharestone',
    'waystones:yellow_sharestone',
    'waystones:lime_sharestone',
    'waystones:pink_sharestone',
    'waystones:gray_sharestone',
    'waystones:light_gray_sharestone',
    'waystones:cyan_sharestone',
    'waystones:purple_sharestone',
    'waystones:blue_sharestone',
    'waystones:brown_sharestone',
    'waystones:green_sharestone',
    'waystones:red_sharestone',
    'waystones:black_sharestone',
    'reliquary:mob_charm',
    'constructionwand:core_destruction'
  ].forEach(item => event.remove({ output: item }));
});

ServerEvents.recipes(event => {
  event.remove({ output: /^ore_creeper/ });
});