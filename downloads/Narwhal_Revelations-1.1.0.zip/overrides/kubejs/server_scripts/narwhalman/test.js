// Delete held items that carry specific custom names.
// Ported to Minecraft 1.21: names are now stored in the `minecraft:custom_name` data component
// (the 1.20.1 version read the old `display.Name` NBT, which no longer exists).
// Ars Nouveau caster tomes keep a scribed spell name in their own component, so that is checked too.
const bannedNamedItems = [
  { id: 'minecraft:stick', name: 'stickyy' },
  { id: 'ars_nouveau:caster_tome', name: 'Self Atomic' },
  { id: 'ars_nouveau:caster_tome', name: "Alex's Magnificent Mansion" },
  { id: 'ars_nouveau:caster_tome', name: "Aurellia's Bite Storm" },
  { id: 'ars_nouveau:caster_tome', name: 'Pixie Pummel' },
  { id: 'ars_nouveau:caster_tome', name: "Yuuki's Mineral Assimilator" },
  { id: 'ars_nouveau:caster_tome', name: 'Arcane Smelt' },
  { id: 'ars_nouveau:caster_tome', name: "Darkfira's Flash Freeze" }

  // Add more items here as needed, e.g.:
  // { id: 'minecraft:dirt', name: 'dirtty' }
];

// Toggle removal functionality (set to true to enable).
const removeNamedItemFromInventory = true;

// True if the stack's custom name (or an Ars Nouveau tome's spell name) is exactly `name`.
function hasBannedName(stack, name) {
  let custom = stack.get('minecraft:custom_name');
  if (custom != null && String(custom.string) === name) return true;
  if (String(stack.hoverName.string) === name) return true;
  if (stack.id === 'ars_nouveau:caster_tome') {
    let comps = String(stack.componentString);
    if (comps.includes('"' + name + '"')) return true;
  }
  return false;
}

// --- Inventory Removal ---
if (removeNamedItemFromInventory) {
  ServerEvents.tick(event => {
    event.server.getPlayers().forEach(player => {
      let inv = player.getInventory();
      for (let i = 0; i < inv.getContainerSize(); i++) {
        let stack = inv.getItem(i);
        if (stack && !stack.isEmpty()) {
          // Check against each banned named item
          for (let bannedItem of bannedNamedItems) {
            if (stack.id === bannedItem.id && hasBannedName(stack, bannedItem.name)) {
              inv.setItem(i, Item.of('minecraft:air'));
              player.tell(`§cBanned named item deleted: ${stack.id}`);
              break; // Stop checking other patterns for this stack
            }
          }
        }
      }
    });
  });
}
