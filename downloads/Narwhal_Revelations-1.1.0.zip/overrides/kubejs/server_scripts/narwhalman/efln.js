// Ported to 1.21.1: the Tinkers' Construct port in this pack (Modern Foundry) uses the modernfoundry: namespace.
ServerEvents.recipes(event => {
  event.remove({ output: 'modernfoundry:efln_ball' });

  event.shaped(Item.of('modernfoundry:efln_ball'), [
    'BBB',
    'BAB',
    'BBB'
  ], {
    A: 'minecraft:flint',
    B: 'minecraft:tnt'
  }).id('narwhalman:gadgets/throwball/efln_ball');
});
