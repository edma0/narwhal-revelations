// onEvent('recipes', event => {
//   //REDSTONE
//   event.custom({
//     "type": "tconstruct:melting",
//     "ingredient": {
//       "item": "minecraft:redstone"
//     },
//     "result": {
//       "fluid": "thermal:redstone",
//       "amount": 100
//     },
//     "temperature": 950,
//     "time": 30
//   })
//   event.custom({
//     "type": "tconstruct:melting",
//     "ingredient": {
//       "tag": "forge:storage_blocks/redstone"
//     },
//     "result": {
//       "fluid": "thermal:redstone",
//       "amount": 900
//     },
//     "temperature": 950,
//     "time": 30
//   })
//   //GLOWSTONE
//   event.custom({
//     "type": "tconstruct:melting",
//     "ingredient": {
//       "item": "minecraft:glowstone_dust"
//     },
//     "result": {
//       "fluid": "thermal:glowstone",
//       "amount": 250
//     },
//     "temperature": 950,
//     "time": 30
//   })
//   event.custom({
//     "type": "tconstruct:melting",
//     "ingredient": {
//       "item": "minecraft:glowstone"
//     },
//     "result": {
//       "fluid": "thermal:glowstone",
//       "amount": 1000
//     },
//     "temperature": 950,
//     "time": 30
//   })  
// })		
