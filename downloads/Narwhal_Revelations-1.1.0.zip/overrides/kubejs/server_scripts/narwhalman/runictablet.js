ServerEvents.recipes(event => {
  event.remove({ id: 'simplyswords:runic_tablet' });
  
  event.shaped(Item.of('simplyswords:runic_tablet'), [
    'BAB',
    'BCB',
    'BBB'
  ], {
    A: 'minecraft:netherite_ingot',
    B: 'minecraft:diamond',
    C: '#c:normal_stone'
  }).id('narwhalman:simplyswords/runic_tablet');
});