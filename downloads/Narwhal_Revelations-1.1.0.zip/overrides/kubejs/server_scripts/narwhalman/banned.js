// Define banned IDs for items and blocks.
// Ported to 1.21.1: Industrial Foregoing lenses are now <color>_laser_lens (old laser_lensN = dye colour N).
// Removed: waystones:sharestone and white_sharestone (no such item in Waystones 1.21.1) and the Hostile Networks items (mod not installed).
const bannedItems = [
    'mekanism:digital_miner',
    'industrialforegoing:ore_laser_base',
    'industrialforegoing:white_laser_lens',
    'industrialforegoing:magenta_laser_lens',
    'industrialforegoing:light_blue_laser_lens',
    'industrialforegoing:yellow_laser_lens',
    'industrialforegoing:lime_laser_lens',
    'industrialforegoing:pink_laser_lens',
    'industrialforegoing:gray_laser_lens',
    'industrialforegoing:light_gray_laser_lens',
    'industrialforegoing:cyan_laser_lens',
    'industrialforegoing:blue_laser_lens',
    'industrialforegoing:brown_laser_lens',
    'industrialforegoing:green_laser_lens',
    'industrialforegoing:red_laser_lens',
    'industrialforegoing:black_laser_lens',
    'botania:orechid',
    'botania:orechid_ignem',
    'waystones:waystone',
    'waystones:mossy_waystone',
    'waystones:sandy_waystone',
    'waystones:orange_sharestone',
    'waystones:magenta_sharestone',
    'waystones:light_blue_sharestone',
    'waystones:yellow_sharestone',
    'waystones:lime_sharestone',
    'waystones:pink_sharestone',
    'waystones:gray_sharestone',
    'waystones:light_gray_sharestone',
    'waystones:cyan_sharestone',
    'waystones:purple_sharestone',
    'waystones:blue_sharestone',
    'waystones:brown_sharestone',
    'waystones:green_sharestone',
    'waystones:red_sharestone',
    'waystones:black_sharestone',
    'reliquary:mob_charm',
    'constructionwand:core_destruction'
  ];
  const bannedBlocks = [
    'industrialforegoing:ore_laser_base'
  ];
  
  // Toggle removal functionality (set to true to enable).
  const removeFromInventory = true;
  const removeFromWorld = true;
  
  // --- Inventory Removal ---
  if (removeFromInventory) {
    ServerEvents.tick(event => {
      event.server.getPlayers().forEach(player => {
        let inv = player.getInventory();
        for (let i = 0; i < inv.getContainerSize(); i++) {
          let stack = inv.getItem(i);
          if (stack && bannedItems.includes(stack.getId())) {
            inv.setItem(i, Item.of('minecraft:air'));
          }
        }
      });
    });
  }
  
  // --- World Removal ---
  if (removeFromWorld) {
    // Use a unique variable name here to avoid conflicts
    let tickCounter = 0;
    
    ServerEvents.tick(event => {
      tickCounter++;
      // Run the removal command every 100 ticks (about every 5 seconds).
      if (tickCounter % 100 === 0) {
        event.server.getPlayers().forEach(player => {
          const pos = player.blockPosition();
          const x1 = pos.x - 10;
          const y1 = pos.y - 10;
          const z1 = pos.z - 10;
          const x2 = pos.x + 10;
          const y2 = pos.y + 10;
          const z2 = pos.z + 10;
          
          bannedBlocks.forEach(blockId => {
            event.server.runCommandSilent(
              `fill ${x1} ${y1} ${z1} ${x2} ${y2} ${z2} minecraft:air replace ${blockId}`
            );
          });
        });
      }
    });
  }
  