ServerEvents.recipes(event => {
    // This recipe creates 1 black dye using one ingredient that can be either coal or charcoal.
    event.shapeless('minecraft:black_dye', [
      Ingredient.of(['minecraft:coal', 'minecraft:charcoal'])
    ])
  })