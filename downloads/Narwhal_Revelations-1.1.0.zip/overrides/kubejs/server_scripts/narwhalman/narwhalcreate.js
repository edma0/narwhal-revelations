// onEvent('recipes', event => {
//   event.custom({
//     "type": "create:crushing",
//     "ingredients": [
//       {
//         "item": "minecraft:raw_iron"
//       }
//     ],
//     "results": [
//       {
//         "item": "alltheores:iron_dust",
//         "count": 2
//       },
//       {
//         "item": "create:experience_nugget",
//         "chance": 0.75
//       }
//     ],
//     "processingTime": 400
//   })
//   event.custom({
//     "type": "create:crushing",
//     "ingredients": [
//       {
//         "item": "minecraft:raw_copper"
//       }
//     ],
//     "results": [
//       {
//         "item": "alltheores:copper_dust",
//         "count": 2
//       },
//       {
//         "item": "create:experience_nugget",
//         "chance": 0.75
//       }
//     ],
//     "processingTime": 400
//   })
//   event.custom({
//     "type": "create:crushing",
//     "ingredients": [
//       {
//         "item": "minecraft:raw_gold"
//       }
//     ],
//     "results": [
//       {
//         "item": "alltheores:gold_dust",
//         "count": 2
//       },
//       {
//         "item": "create:experience_nugget",
//         "chance": 0.75
//       }
//     ],
//     "processingTime": 400
//   })
// })		
